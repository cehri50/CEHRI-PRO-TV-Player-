// ==================== MOCK API ====================
console.log("🤖 MockAPI yükleniyor...");

class MockAPI {
    constructor() {
        console.log("✅ MockAPI aktif");
        this.mockChannels = [
            { id: 101, name: 'TRT 1 HD', url: 'https://tv-trtworld.medya.trt.com.tr/master.m3u8', group: 'Yerel' },
            { id: 102, name: 'Show TV', url: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8', group: 'Yerel' },
            { id: 103, name: 'CNN Türk', url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8', group: 'Haber' },
            { id: 104, name: 'BBC World News', url: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8', group: 'Haber' },
            { id: 105, name: 'National Geographic', url: 'https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8', group: 'Belgesel' },
            { id: 106, name: 'Big Buck Bunny', url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8', group: 'Film' }
        ];
    }
    
    async getChannels() {
        console.log("🤖 MockAPI: 6 kanal döndürülüyor");
        return new Promise(resolve => {
            setTimeout(() => resolve(this.mockChannels), 500);
        });
    }
    
    async saveFavorites(favoriteIds) {
        console.log("🤖 MockAPI: " + favoriteIds.size + " favori kaydedildi");
        return new Promise(resolve => {
            setTimeout(() => resolve({ success: true }), 300);
        });
    }
    
    async getFavorites() {
        console.log("🤖 MockAPI: Boş favori listesi");
        return new Promise(resolve => {
            setTimeout(() => resolve([]), 300);
        });
    }
}

// ==================== VIDEO PLAYER ====================
console.log("🚀 CEHRI PRO v10.0 Player yükleniyor...");

class VideoPlayer {
    constructor() {
        console.log("VideoPlayer constructor çalıştı");
        this.video = document.getElementById('hlsVideo');
        this.hls = null;
        this.currentChannel = null;
        this.favorites = new Set();
        this.channels = [];
        this.api = null;
        
        if (Hls.isSupported()) {
            console.log("✅ HLS.js destekleniyor");
        } else {
            console.log("❌ HLS desteklenmiyor");
        }
        
        this.init();
    }
    
    async init() {
        console.log("Player başlatılıyor...");
        await this.loadChannels();
        this.setupEventListeners();
        
        if (this.channels.length > 0) {
            this.playChannel(this.channels[0]);
        }
        
        this.loadFavorites();
        this.updateStatus('Player hazır...');
        console.log("✅ Player başlatma tamamlandı");
    }
    
    async loadChannels() {
        console.log("📡 Kanallar yükleniyor...");
        this.api = new MockAPI();
        
        try {
            const backendChannels = await this.api.getChannels();
            this.channels = backendChannels || [];
            console.log("✅ " + this.channels.length + " mock kanalı yüklendi");
        } catch (error) {
            console.log("📺 Test kanalları kullanılıyor");
            this.channels = [
                { id: 1, name: 'TRT World Test', url: 'https://tv-trtworld.medya.trt.com.tr/master.m3u8', group: 'Test' },
                { id: 2, name: 'Demo Stream', url: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8', group: 'Test' },
                { id: 3, name: 'Big Buck Bunny', url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8', group: 'Test' }
            ];
        }
        
        try {
            const backendFavorites = await this.api.getFavorites();
            if (backendFavorites && backendFavorites.length > 0) {
                this.favorites = new Set(backendFavorites);
            } else {
                this.loadFavorites();
            }
        } catch (error) {
            this.loadFavorites();
        }
        
        this.renderChannelsList();
        this.renderFavorites();
        console.log("🎬 Player hazır!");
    }
    
    setupEventListeners() {
        document.getElementById('playBtn').addEventListener('click', () => {
            this.video.play();
            this.updateStatus('Oynatılıyor...');
        });
        
        document.getElementById('pauseBtn').addEventListener('click', () => {
            this.video.pause();
            this.updateStatus('Duraklatıldı');
        });
        
        document.getElementById('fullscreenBtn').addEventListener('click', () => {
            this.toggleFullscreen();
        });
        
        document.getElementById('favoriteBtn').addEventListener('click', () => {
            this.toggleFavorite();
        });
        
        this.video.addEventListener('loadeddata', () => {
            this.updateStatus('Yüklendi: ' + (this.currentChannel?.name || ''));
        });
    }
    
    playChannel(channel) {
        console.log("Kanal oynatılıyor: " + channel.name);
        this.currentChannel = channel;
        
        if (this.hls) {
            this.hls.destroy();
        }
        
        if (Hls.isSupported()) {
            this.hls = new Hls({
                enableWorker: true,
                lowLatencyMode: false,
                backBufferLength: 60,
                maxBufferLength: 30
            });
            
            this.hls.loadSource(channel.url);
            this.hls.attachMedia(this.video);
            
            this.hls.on(Hls.Events.MANIFEST_PARSED, () => {
                this.video.play().catch(e => {
                    console.log('Auto-play prevented');
                    this.updateStatus('Oynatmak için play tuşuna basın');
                });
            });
        } else if (this.video.canPlayType('application/vnd.apple.mpegurl')) {
            this.video.src = channel.url;
        }
        
        this.updateActiveChannel();
        this.updateFavoriteButton();
        this.updateStatus(channel.name + ' yükleniyor...');
    }
    
    renderChannelsList() {
        const container = document.getElementById('channelsContainer');
        container.innerHTML = '';
        
        // Gruplara ayır
        const groups = {};
        this.channels.forEach(channel => {
            const group = channel.group || 'Diğer';
            if (!groups[group]) groups[group] = [];
            groups[group].push(channel);
        });
        
        Object.keys(groups).forEach(groupName => {
            // Grup başlığı
            const groupHeader = document.createElement('div');
            groupHeader.className = 'channel-group';
            groupHeader.textContent = groupName;
            container.appendChild(groupHeader);
            
            // Kanal listesi
            groups[groupName].forEach(channel => {
                const div = document.createElement('div');
                div.className = 'channel-item ' + (this.currentChannel?.id === channel.id ? 'active' : '');
                div.innerHTML = '<div><strong>' + channel.name + '</strong></div>' +
                               '<button class="favorite-btn" data-id="' + channel.id + '">' + 
                               (this.favorites.has(channel.id) ? '★' : '☆') + '</button>';
                
                div.addEventListener('click', (e) => {
                    if (!e.target.classList.contains('favorite-btn')) {
                        this.playChannel(channel);
                    }
                });
                
                div.querySelector('.favorite-btn').addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.toggleFavorite(channel.id);
                    this.renderChannelsList();
                    this.renderFavorites();
                });
                
                container.appendChild(div);
            });
        });
    }
    
    updateActiveChannel() {
        document.querySelectorAll('.channel-item').forEach(item => {
            const btn = item.querySelector('.favorite-btn');
            if (btn) {
                const channelId = parseInt(btn.dataset.id);
                item.classList.toggle('active', channelId === this.currentChannel?.id);
            }
        });
    }
    
    toggleFavorite(channelId = null) {
        const id = channelId || this.currentChannel?.id;
        if (!id) return;
        
        const channelName = this.channels.find(c => c.id === id)?.name;
        
        if (this.favorites.has(id)) {
            this.favorites.delete(id);
            console.log("➖ Favorilerden çıkarıldı: " + channelName);
        } else {
            this.favorites.add(id);
            console.log("➕ Favorilere eklendi: " + channelName);
        }
        
        localStorage.setItem('cehri_favorites', JSON.stringify([...this.favorites]));
        
        if (this.api) {
            this.api.saveFavorites(this.favorites);
        }
        
        this.updateFavoriteButton();
        this.renderFavorites();
    }
    
    loadFavorites() {
        const saved = localStorage.getItem('cehri_favorites');
        if (saved) {
            this.favorites = new Set(JSON.parse(saved));
        }
    }
    
    renderFavorites() {
        const container = document.getElementById('favoritesContainer');
        container.innerHTML = '';
        
        if (this.favorites.size === 0) {
            container.innerHTML = '<p style="text-align: center; padding: 20px;">⭐ Henüz favori kanalınız yok</p>';
            return;
        }
        
        this.channels
            .filter(channel => this.favorites.has(channel.id))
            .forEach(channel => {
                const div = document.createElement('div');
                div.className = 'channel-item';
                div.innerHTML = '<div><strong>' + channel.name + '</strong></div>' +
                               '<button class="favorite-btn" data-id="' + channel.id + '">★</button>';
                
                div.addEventListener('click', () => this.playChannel(channel));
                div.querySelector('.favorite-btn').addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.toggleFavorite(channel.id);
                    this.renderChannelsList();
                });
                
                container.appendChild(div);
            });
    }
    
    updateFavoriteButton() {
        const btn = document.getElementById('favoriteBtn');
        if (this.currentChannel && this.favorites.has(this.currentChannel.id)) {
            btn.innerHTML = '★ Favoriden Çıkar';
            btn.style.background = 'linear-gradient(45deg, gold, orange)';
        } else {
            btn.innerHTML = '⭐ Favori Ekle';
            btn.style.background = 'linear-gradient(45deg, #00ff88, #00ccff)';
        }
    }
    
    updateStatus(message, type = 'info') {
        const statusEl = document.getElementById('status');
        statusEl.textContent = message;
        statusEl.style.background = type === 'error' ? 
            'rgba(255, 50, 50, 0.2)' : 'rgba(0, 255, 136, 0.1)';
    }
    
    toggleFullscreen() {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen();
        } else {
            document.exitFullscreen();
        }
    }
}

// Player başlat
document.addEventListener('DOMContentLoaded', () => {
    console.log("DOM yüklendi, player başlatılıyor...");
    try {
        window.player = new VideoPlayer();
        console.log("✅ CEHRI PRO v10.0 Player başlatıldı!");
    } catch (error) {
        console.error("❌ Player başlatma hatası:", error);
    }
});
