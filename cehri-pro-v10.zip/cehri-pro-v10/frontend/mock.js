// ==================== MOCK API ====================
class MockAPI {
    constructor() {
        console.log("🤖 MockAPI aktif");
        this.mockChannels = [
            { id: 1, name: 'TRT 1 HD', url: 'https://tv-trtworld.medya.trt.com.tr/master.m3u8', group: 'Yerel' },
            { id: 2, name: 'Show TV', url: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8', group: 'Yerel' },
            { id: 3, name: 'CNN Türk', url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8', group: 'Haber' },
            { id: 4, name: 'BBC World', url: 'https://bitdash-a.akamaihd.net/s/content/media/Manifest_1080p.m3u8', group: 'Haber' },
            { id: 5, name: 'NatGeo', url: 'https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8', group: 'Belgesel' },
            { id: 6, name: 'Big Buck Bunny', url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8', group: 'Film' }
        ];
    }
    
    async getChannels() {
        console.log("🤖 6 mock kanal döndürülüyor");
        return this.mockChannels;
    }
    
    async saveFavorites(favs) {
        console.log("🤖 Favoriler kaydedildi (simülasyon)");
        return { success: true };
    }
    
    async getFavorites() {
        return [];
    }
}
