const express = require("express");
const cors = require("cors");
const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Health check
app.get("/api/health", (req, res) => {
    res.json({ 
        status: "OK", 
        version: "10.0.0",
        message: "CEHRI PRO Backend çalışıyor",
        timestamp: new Date().toISOString()
    });
});

// Test kanalları
app.get("/api/m3u", (req, res) => {
    const channels = [
        {
            id: 1,
            name: "TRT World Test",
            url: "https://tv-trtworld.medya.trt.com.tr/master.m3u8",
            group: "Haber",
            logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/db/TRT_World_logo.svg/1200px-TRT_World_logo.svg.png"
        },
        {
            id: 2,
            name: "Demo Stream",
            url: "https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8",
            group: "Demo",
            logo: "https://unified-streaming.com/images/unified-streaming-logo.svg"
        },
        {
            id: 3,
            name: "Big Buck Bunny",
            url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
            group: "Film",
            logo: "https://peach.blender.org/wp-content/uploads/bbb-splash.png"
        },
        {
            id: 4,
            name: "CNN Türk (Test)",
            url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
            group: "Haber",
            logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/CNN_T%C3%BCrk_logosu.png/800px-CNN_T%C3%BCrk_logosu.png"
        }
    ];
    
    console.log("[API] " + channels.length + " kanal gönderiliyor");
    res.json(channels);
});

// Favoriler (basit bellek depolama)
let favorites = [1, 3]; // Varsayılan favoriler: TRT ve CNN

app.get("/api/favorites", (req, res) => {
    console.log("[API] " + favorites.length + " favori gönderiliyor");
    res.json(favorites);
});

app.post("/api/favorites", (req, res) => {
    favorites = req.body.favorites || [];
    console.log("[API] " + favorites.length + " favori kaydedildi");
    res.json({ success: true, count: favorites.length });
});

// Server başlat
app.listen(PORT, () => {
    console.log("========================================");
    console.log("🚀 CEHRI PRO Backend v10.0 BAŞLATILDI!");
    console.log("========================================");
    console.log("📡 Port: http://localhost:" + PORT);
    console.log("");
    console.log("✅ Endpoints:");
    console.log("   GET  http://localhost:3000/api/health");
    console.log("   GET  http://localhost:3000/api/m3u");
    console.log("   GET  http://localhost:3000/api/favorites");
    console.log("   POST http://localhost:3000/api/favorites");
    console.log("");
    console.log("⚡ Frontend: http://localhost:8080");
    console.log("========================================");
});
