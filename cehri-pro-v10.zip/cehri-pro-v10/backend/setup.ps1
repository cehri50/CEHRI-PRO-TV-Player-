// Backend kurulumu için PowerShell script
Write-Host "🚀 CEHRI PRO Backend Kurulumu Başlıyor..." -ForegroundColor Green

# package.json oluştur
@"
{
  "name": "cehri-pro-backend",
  "version": "10.0.0",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5"
  }
}
"@ | Out-File -FilePath "package.json" -Encoding UTF8
Write-Host "✅ package.json oluşturuldu" -ForegroundColor Green

# server.js oluştur  
@"
const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Sağlık kontrolü
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'OK', 
        version: '10.0.0',
        message: 'CEHRI PRO Backend çalışıyor',
        timestamp: new Date().toISOString()
    });
});

// Test kanalları
app.get('/api/m3u', (req, res) => {
    const channels = [
        {
            id: 1,
            name: 'TRT World Test',
            url: 'https://tv-trtworld.medya.trt.com.tr/master.m3u8',
            group: 'Haber'
        },
        {
            id: 2,
            name: 'Demo Stream',
            url: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8',
            group: 'Demo'
        },
        {
            id: 3,
            name: 'Big Buck Bunny',
            url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
            group: 'Film'
        }
    ];
    res.json(channels);
});

// Favoriler (basit bellek depolama)
let favorites = [];

app.get('/api/favorites', (req, res) => {
    res.json(favorites);
});

app.post('/api/favorites', (req, res) => {
    favorites = req.body.favorites || [];
    res.json({ success: true, count: favorites.length });
});

app.listen(PORT, () => {
    console.log(\`🚀 CEHRI PRO Backend: http://localhost:\${PORT}\`);
});
"@ | Out-File -FilePath "server.js" -Encoding UTF8
Write-Host "✅ server.js oluşturuldu" -ForegroundColor Green

# Bağımlılıkları yükle
Write-Host "📦 Bağımlılıklar yükleniyor..." -ForegroundColor Yellow
npm install

Write-Host "🎉 Backend kurulumu tamamlandı!" -ForegroundColor Green
Write-Host "▶️  Çalıştırmak için: npm start" -ForegroundColor Cyan
